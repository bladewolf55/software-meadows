$current = $PSScriptRoot

# This is the new "standard" path
$basePath = "$env:LOCALAPPDATA\Programs\Microsoft VS Code\resources\app\resources\win32\"

If (-Not (Test-Path $basePath))
{
    # This is the old path
    $basePath = "$env:ProgramFiles\Microsoft VS Code\resources\app\resources\win32\"
}

Write-Output "VS Code Path: $basePath"


Write-Output "Copying orange icons"
$iconFile = Join-Path $basePath  "code_file.ico"

Copy-Item -Path @(Join-Path $current *) -Include *.png,*.ico -Destination $basePath

Write-Output "Setting Registry..."
New-PSDrive -PSProvider registry -Root HKEY_CLASSES_ROOT -Name HKCR
Set-ItemProperty -LiteralPath "HKCR:\*\shell\VSCode" -Name Icon -Value $iconFile
Set-ItemProperty -Path HKCR:\Directory\Background\shell\VSCode -Name Icon -Value $iconFile
Set-ItemProperty -Path HKCR:\Drive\shell\VSCode -Name Icon -Value $iconFile
Set-ItemProperty -Path HKCU:\Software\Classes\Directory\shell\VSCode -Name Icon -Value $iconFile
Remove-PSDrive -Name HKCR 

Write-Output "Creating shortcut in Desktop"
$TargetFile = $basePath + "..\..\..\..\code.exe"
$ShortcutFile = "$env:UserProfile\Desktop\VS Code.lnk"
$WScriptShell = New-Object -ComObject WScript.Shell
$Shortcut = $WScriptShell.CreateShortcut($ShortcutFile)
$Shortcut.TargetPath = $TargetFile
$Shortcut.IconLocation = $iconFile
$Shortcut.Save()

Write-Output "Finished."
Pause