$path = "C:\Program Files\Microsoft VS Code\resources\app\resources\win32\code_file.ico"

New-PSDrive -PSProvider registry -Root HKEY_CLASSES_ROOT -Name HKCR
Write-Output "Setting..."
Set-ItemProperty -LiteralPath "HKCR:\*\shell\VSCode" -Name Icon -Value $path
Set-ItemProperty -Path HKCR:\Directory\Background\shell\VSCode -Name Icon -Value $path
Set-ItemProperty -Path HKCR:\Drive\shell\VSCode -Name Icon -Value $path
Set-ItemProperty -Path HKCU:\Software\Classes\Directory\shell\VSCode -Name Icon -Value $path
Write-Output "Finished."
Pause